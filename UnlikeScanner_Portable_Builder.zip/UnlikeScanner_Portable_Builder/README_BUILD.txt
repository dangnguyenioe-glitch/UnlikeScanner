UNLIKE SCANNER — WINDOWS PORTABLE BUILDER

Muc dich:
- Tao UnlikeScanner.exe bang GitHub Actions tren may chu Windows cua GitHub.
- Nguoi dung khong can cai Python, khong can CMD, khong can cai PyInstaller.
- Ung dung can Microsoft Edge duoc cai san de mo Facebook.

CACH LAY FILE EXE:
1. Dang nhap GitHub va tao repository moi (co the de Private).
2. Giai nen goi nay tren may tinh.
3. Tai len TOAN BO noi dung ben trong thu muc UnlikeScanner_Portable_Builder vao repository.
   Can giu ca thu muc an .github/workflows/build-windows.yml.
4. Mo repository > tab Actions.
5. Chon workflow "Build Unlike Scanner for Windows".
6. Bam "Run workflow".
7. Cho workflow chay xong, mo run vua hoan tat.
8. O muc Artifacts, tai "UnlikeScanner-Windows-Portable.zip".
9. Giai nen va chay UnlikeScanner.exe.

LUU Y:
- Day la ban thu nghiem. Khong dam bao nhan dien dung moi bai viet Facebook.
- Hay thu voi mot so bai nho va kiem tra bang tay truoc khi dung rong.
- Chi thao tac tren tai khoan cua chinh minh. Khong vuot CAPTCHA hay co che bao ve.
- Khong nhap mat khau Facebook vao ung dung.
- Ung dung dung Microsoft Edge da cai tren Windows.
- File EXE duoc tao tu ma nguon nay; goi builder khong phai file EXE da build san.
- GitHub Actions cai Python tren may chu GitHub, khong cai tren may cua em.
