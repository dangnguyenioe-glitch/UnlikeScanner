import hashlib
import queue
import re
import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path

from playwright.sync_api import sync_playwright

APP_DIR = Path.home() / "UnlikeScanner"
PROFILE_DIR = APP_DIR / "facebook_browser_profile"
DB_FILE = APP_DIR / "processed_posts.txt"

# Chỉ nhận diện trạng thái đã thích. Không tìm nút "Like" thông thường để bấm.
LIKE_WORDS = ("like", "liked", "thích", "đã thích", "bỏ thích", "unlike")
UNLIKE_WORDS = ("unlike", "bỏ thích", "remove like", "remove reaction")

class UnlikeScanner:
    def __init__(self, root):
        self.root = root
        self.root.title("Unlike Scanner — Facebook Edition")
        self.root.geometry("760x560")
        self.root.minsize(680, 480)

        self.messages = queue.Queue()
        self.stop_event = threading.Event()
        self.browser_thread = None
        self.context = None
        self.page = None
        self.scanning = False
        self.processed = self.load_processed()

        self.build_ui()
        self.root.after(150, self.drain_messages)
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)

    def build_ui(self):
        outer = ttk.Frame(self.root, padding=18)
        outer.pack(fill="both", expand=True)

        ttk.Label(outer, text="UNLIKE SCANNER", font=("Segoe UI", 22, "bold")).pack(anchor="w")
        ttk.Label(outer, text="Facebook Edition • Quét bài viết trên trang cá nhân",
                  font=("Segoe UI", 10)).pack(anchor="w", pady=(0, 14))

        info = ttk.LabelFrame(outer, text="Cấu hình", padding=12)
        info.pack(fill="x")
        ttk.Label(info, text="Phạm vi: Tất cả bài viết trên trang cá nhân").grid(row=0, column=0, sticky="w")
        ttk.Label(info, text="Chế độ: Tự động bỏ thích bài đã thích").grid(row=1, column=0, sticky="w", pady=(5, 0))
        ttk.Label(info, text="Tốc độ: Chậm, có thời gian nghỉ giữa các thao tác").grid(row=2, column=0, sticky="w", pady=(5, 0))

        controls = ttk.Frame(outer)
        controls.pack(fill="x", pady=14)
        self.open_btn = ttk.Button(controls, text="1. Mở Facebook", command=self.open_facebook)
        self.open_btn.pack(side="left", padx=(0, 8))
        self.scan_btn = ttk.Button(controls, text="2. Bắt đầu quét", command=self.start_scan, state="disabled")
        self.scan_btn.pack(side="left", padx=8)
        self.stop_btn = ttk.Button(controls, text="DỪNG NGAY", command=self.stop_scan, state="disabled")
        self.stop_btn.pack(side="left", padx=8)

        self.status = tk.StringVar(value="Chưa kết nối")
        ttk.Label(outer, textvariable=self.status, font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(0, 6))

        self.log = tk.Text(outer, height=16, wrap="word", font=("Consolas", 9), state="disabled")
        self.log.pack(fill="both", expand=True)

        ttk.Label(
            outer,
            text="Lưu ý: Em tự đăng nhập và mở trang cá nhân trong cửa sổ trình duyệt. "
                 "Không nhập mật khẩu vào ứng dụng. Không vượt CAPTCHA hoặc cơ chế bảo vệ của Facebook.",
            wraplength=710, foreground="#555"
        ).pack(anchor="w", pady=(10, 0))

    def write_log(self, message):
        self.messages.put(("log", message))

    def set_status(self, message):
        self.messages.put(("status", message))

    def drain_messages(self):
        try:
            while True:
                kind, value = self.messages.get_nowait()
                if kind == "log":
                    self.log.configure(state="normal")
                    self.log.insert("end", value + "\n")
                    self.log.see("end")
                    self.log.configure(state="disabled")
                elif kind == "status":
                    self.status.set(value)
                elif kind == "connected":
                    self.scan_btn.configure(state="normal")
                elif kind == "finished":
                    self.scanning = False
                    self.stop_btn.configure(state="disabled")
                    self.scan_btn.configure(state="normal" if self.page else "disabled")
        except queue.Empty:
            pass
        self.root.after(150, self.drain_messages)

    def open_facebook(self):
        if self.browser_thread and self.browser_thread.is_alive():
            messagebox.showinfo("Thông tin", "Trình duyệt đang được mở.")
            return
        self.browser_thread = threading.Thread(target=self.browser_worker, daemon=True)
        self.browser_thread.start()

    def browser_worker(self):
        try:
            APP_DIR.mkdir(parents=True, exist_ok=True)
            PROFILE_DIR.mkdir(parents=True, exist_ok=True)
            self.set_status("Đang mở trình duyệt…")
            self.write_log("Đang mở Microsoft Edge/Chromium với hồ sơ riêng của ứng dụng.")
            self.pw = sync_playwright().start()
            self.context = self.pw.chromium.launch_persistent_context(
                user_data_dir=str(PROFILE_DIR),
                headless=False,
                channel="msedge",
                viewport={"width": 1360, "height": 900},
                args=["--start-maximized"]
            )
            self.page = self.context.pages[0] if self.context.pages else self.context.new_page()
            self.page.goto("https://www.facebook.com/", wait_until="domcontentloaded", timeout=60000)
            self.write_log("Hãy tự đăng nhập Facebook trong cửa sổ vừa mở.")
            self.write_log("Sau khi đăng nhập, tự mở trang cá nhân của em rồi quay lại bấm 'Bắt đầu quét'.")
            self.set_status("Đã mở trình duyệt — chờ em đăng nhập và mở trang cá nhân.")
            self.messages.put(("connected", None))
        except Exception as e:
            self.write_log(f"Lỗi mở trình duyệt: {e}")
            self.set_status("Không mở được trình duyệt. Kiểm tra Microsoft Edge hoặc cài đặt Playwright.")

    def load_processed(self):
        try:
            return set(DB_FILE.read_text(encoding="utf-8").splitlines())
        except FileNotFoundError:
            return set()

    def save_processed(self, key):
        APP_DIR.mkdir(parents=True, exist_ok=True)
        with DB_FILE.open("a", encoding="utf-8") as f:
            f.write(key + "\n")
        self.processed.add(key)

    @staticmethod
    def normalize(s):
        return re.sub(r"\s+", " ", (s or "").strip().lower())

    def post_key(self, article):
        # Ưu tiên permalink của bài viết; nếu không có thì dùng hash nội dung.
        try:
            links = article.locator('a[href*="/posts/"], a[href*="/permalink/"], a[href*="story_fbid"]').evaluate_all(
                "(els) => els.map(a => a.href)"
            )
            if links:
                return hashlib.sha256(links[0].encode("utf-8")).hexdigest()
            content = article.inner_text(timeout=1500)[:3000]
            return hashlib.sha256(content.encode("utf-8")).hexdigest()
        except Exception:
            return ""

    def is_liked_button(self, button):
        try:
            label = self.normalize(button.get_attribute("aria-label"))
            title = self.normalize(button.get_attribute("title"))
            text = self.normalize(button.inner_text(timeout=700))
            combined = " ".join([label, title, text])

            # Ưu tiên trạng thái pressed=true; sau đó yêu cầu nhãn có ý nghĩa Like.
            pressed = self.normalize(button.get_attribute("aria-pressed"))
            if pressed == "true" and any(w in combined for w in LIKE_WORDS):
                return True

            # Một số giao diện dùng nhãn trực tiếp "Unlike / Bỏ thích".
            if any(w in combined for w in UNLIKE_WORDS):
                return True
        except Exception:
            return False
        return False

    def start_scan(self):
        if not self.page:
            return
        if self.scanning:
            return
        try:
            current = self.page.url
            if "facebook.com" not in current:
                messagebox.showwarning("Sai trang", "Hãy mở Facebook và trang cá nhân trước.")
                return
            if "facebook.com" in current and current.rstrip("/") in ("https://www.facebook.com", "https://www.facebook.com/?sk=…"):
                messagebox.showwarning("Chưa mở trang cá nhân", "Hãy mở trang cá nhân của em trước khi quét.")
                return
        except Exception:
            messagebox.showwarning("Trình duyệt", "Không thể đọc trang hiện tại.")
            return

        if not messagebox.askyesno(
            "Xác nhận quét",
            "Ứng dụng sẽ tự bỏ thích các bài viết được nhận diện là đã thích trên trang cá nhân. "
            "Em có thể bấm DỪNG NGAY bất cứ lúc nào. Tiếp tục?"
        ):
            return

        self.stop_event.clear()
        self.scanning = True
        self.scan_btn.configure(state="disabled")
        self.stop_btn.configure(state="normal")
        threading.Thread(target=self.scan_worker, daemon=True).start()

    def scan_worker(self):
        self.set_status("Đang quét bài viết…")
        self.write_log("Bắt đầu quét. Không đóng cửa sổ trình duyệt.")
        seen_this_run = set()
        idle_rounds = 0
        unliked_count = 0
        scanned_count = 0

        try:
            while not self.stop_event.is_set() and idle_rounds < 8:
                articles = self.page.locator('[role="article"]')
                count = articles.count()
                new_in_round = 0

                for i in range(count):
                    if self.stop_event.is_set():
                        break
                    article = articles.nth(i)
                    key = self.post_key(article)
                    if not key or key in seen_this_run or key in self.processed:
                        continue
                    seen_this_run.add(key)
                    new_in_round += 1
                    scanned_count += 1

                    try:
                        buttons = article.locator('div[role="button"], button')
                        liked = None
                        for j in range(min(buttons.count(), 80)):
                            candidate = buttons.nth(j)
                            if self.is_liked_button(candidate):
                                liked = candidate
                                break

                        if liked is not None:
                            label = (liked.get_attribute("aria-label") or liked.inner_text(timeout=500) or "Like").strip()
                            self.write_log(f"Phát hiện bài đã thích: {label[:70]}")
                            if not self.stop_event.is_set():
                                liked.click(timeout=3000)
                                unliked_count += 1
                                self.write_log("  → Đã gửi thao tác bỏ thích.")
                                time.sleep(3.0)
                        else:
                            self.write_log("Bài chưa được nhận diện là đã thích — giữ nguyên.")
                        self.save_processed(key)
                    except Exception as e:
                        self.write_log(f"Bỏ qua một bài do giao diện thay đổi/lỗi: {str(e)[:120]}")

                if self.stop_event.is_set():
                    break

                if new_in_round == 0:
                    idle_rounds += 1
                else:
                    idle_rounds = 0

                self.page.mouse.wheel(0, 700)
                time.sleep(2.2)

            if idle_rounds >= 8:
                self.write_log("Không tìm thấy bài mới sau nhiều lần cuộn. Có thể đã đến cuối nội dung tải được.")
        except Exception as e:
            self.write_log(f"Quá trình quét dừng do lỗi: {e}")

        self.write_log(f"Kết thúc phiên: đã kiểm tra {scanned_count} bài; gửi {unliked_count} thao tác bỏ thích.")
        self.set_status("Đã dừng." if self.stop_event.is_set() else "Hoàn tất lượt quét hiện tại.")
        self.messages.put(("finished", None))

    def stop_scan(self):
        self.stop_event.set()
        self.set_status("Đang dừng…")
        self.write_log("Đã nhận lệnh DỪNG NGAY. Đợi thao tác hiện tại kết thúc.")

    def on_close(self):
        if self.scanning and not messagebox.askyesno("Thoát", "Đang quét. Dừng và thoát ứng dụng?"):
            return
        self.stop_event.set()
        try:
            if self.context:
                self.context.close()
            if hasattr(self, "pw"):
                self.pw.stop()
        except Exception:
            pass
        self.root.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    try:
        ttk.Style().theme_use("vista")
    except Exception:
        pass
    app = UnlikeScanner(root)
    root.mainloop()
